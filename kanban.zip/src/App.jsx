import React from "react";
import Navbar from "./Components/Navbar";
import Main from "./Components/Main";
import Board from "./Components/Board/Board"
import GroupSelector from "./Components/GroupSelector/GroupSelector";



import './App.css'

export default function App() {
  return (
    <div className="app">
      <div className="app_navbar">
       <GroupSelector />
      </div>
      <div className="app_outer">
        <div className="app_boards">
          <Board />
           <Board /> 
          <Board /> 
          <Board /> 
          <Board />
        </div>
      </div>
    </div>

  )
}
