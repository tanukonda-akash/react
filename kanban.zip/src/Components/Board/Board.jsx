import React from 'react';
import "./Board.css";
import Card from "../Card/Card";
import CardForm from "../CardForm/CardForm";
function Board() {
  return (
    <div className="board">
     <div className="board_top">
         <p className="board_top_title">To do   <span>  2</span></p>
         <i class="fa-solid fa-ellipsis"></i>
     </div>
      
      <div className="board_cards">
         <Card />
         <Card />
        <CardForm />
      </div>
      
    </div>
  )
  
}

export default Board;
