import React from 'react';
import "./Card.css";

function Card(){
  return(
      <div className="kanban_card">
          <div className="kanban_card_header">
         
            <h3>CAM-1</h3>
            <i class="fa-solid fa-user"></i>
          </div>
          <div className="kanban_card_body">
            <h2>lets try</h2>
          </div>
          <div className="kanban_card_footer">
            <p >
              <i class="fa-solid fa-circle-check"></i>
                feature Request
            </p>
            
           </div>
          
    </div>
    
    )
}
export default Card;