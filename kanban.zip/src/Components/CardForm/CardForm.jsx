// src/components/CardForm.js
import React, { useState } from 'react';

const CardForm = ({ onAddCard }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('To Do');
  const [user, setUser] = useState('User A');
  const [priority, setPriority] = useState('Medium');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newCard = { title, status, user, priority };
    onAddCard(newCard);
    // Clear form fields
    setTitle('');
    setStatus('To Do');
    setUser('User A');
    setPriority('Medium');
    setIsEditing(false); // Switch back to non-editing mode
  };

  return (
    <div>
      {isEditing ? (
        <form onSubmit={handleSubmit} className="card-form">
          <label>
            Title:
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
          </label>
          <label>
            Status:
            <select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="To Do">To Do</option>
              <option value="In Progress">In Progress</option>
              <option value="Done">Done</option>
            </select>
          </label>
          <label>
            User:
            <input type="text" value={user} onChange={(e) => setUser(e.target.value)} />
          </label>
          <label>
            Priority:
            <select value={priority} onChange={(e) => setPriority(e.target.value)}>
              <option value="Urgent">Urgent</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </label>
          <button type="submit">Add Card</button>
        </form>
      ) : (
        <p onClick={() => setIsEditing(true)}>ADD CARD </p>
      )}
    </div>
  );
};

export default CardForm;
