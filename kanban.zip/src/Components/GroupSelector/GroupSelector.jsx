// src/components/GroupSelector.js
import React from 'react';

const GroupSelector = ({ selectedGroup, setSelectedGroup }) => {
  return (
    <div>
      <label>
       
        <select value={selectedGroup} onChange={(e) => setSelectedGroup(e.target.value)}>
          <option value="status">Status</option>
          <option value="user">User</option>
          <option value="priority">Priority</option>
        </select>
      </label>
    </div>
  );
};

export default GroupSelector;
