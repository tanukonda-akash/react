import React from 'react';

export default function Navbar(){
  return(
    <nav> 
       
       <h2>KanBan</h2>
    </nav>
  )
}